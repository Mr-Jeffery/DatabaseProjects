from prisma import Prisma

db = Prisma()
